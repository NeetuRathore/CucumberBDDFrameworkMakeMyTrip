package utils;
import java.io.IOException;

import org.openqa.selenium.*;

import pageObjects.CapabilitesPageObject;
import pageObjects.CheckoutPageObject;
import pageObjects.MyntraPageObject;
import pageObjects.SearchProductPageObject;
import stepDefination.Hooks;

public class TestContextSetup {
	
	public WebDriver driver;
	public GenericUtils genericUtils;
	public SearchProductPageObject searchProductPageObject;
	public BaseTest test;
	public CheckoutPageObject checkoutPageObject;
	public CapabilitesPageObject capabilitiesPageObject;
	public MyntraPageObject myntraPageObject;
	
	public TestContextSetup() throws IOException {
		test = new BaseTest();
		searchProductPageObject = new SearchProductPageObject(test.driver);
		genericUtils = new GenericUtils(test.driver);
		checkoutPageObject = new CheckoutPageObject(test.driver);
		capabilitiesPageObject = new CapabilitesPageObject(test.driver);
		myntraPageObject = new MyntraPageObject(test.driver);
		
		
	}
	
	

}
