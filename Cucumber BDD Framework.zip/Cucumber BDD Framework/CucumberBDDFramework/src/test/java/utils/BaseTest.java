package utils;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.GeckoDriverInfo;

public class BaseTest {
	
	public WebDriver driver;
	public String URL;
	public String browser;
	
	public BaseTest() throws IOException {
		this.driver =setUpBrowser(); 
	}
	
	public WebDriver setUpBrowser() throws IOException {
		FileInputStream fs = new FileInputStream("global.properties");
		Properties prop = new Properties();
		prop.load(fs);
		URL= prop.getProperty("Url");
		browser = prop.getProperty("browser");
		
		if(driver==null) {
			if(browser.equalsIgnoreCase("chrome")) {
				ChromeOptions options = new ChromeOptions();
				options.addArguments("--disable-notifications");
				options.addArguments("--disable-extensions");
				options.addArguments("--disable-blink-features=AutomationControlled");
				options.addArguments("--disable-extensions");

				driver = new ChromeDriver(options);
				return driver;	
			}else if(browser.equalsIgnoreCase("firefox")) {
				driver= new FirefoxDriver();
				return driver;
			}
					
		}
		
		return driver;
		
	}

}
