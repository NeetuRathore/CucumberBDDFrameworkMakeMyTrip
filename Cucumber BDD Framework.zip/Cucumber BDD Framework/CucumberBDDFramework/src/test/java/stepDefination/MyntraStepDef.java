package stepDefination;

import io.cucumber.java.en.*;
import utils.TestContextSetup;

public class MyntraStepDef {
	
	TestContextSetup testContextSetup;
	
	public MyntraStepDef(TestContextSetup testContextSetup) {
		this.testContextSetup=testContextSetup;
	}
	
	@Given("User launch Myntra application")
	public void user_is_on_home_page_of_myntra() {
	    testContextSetup.myntraPageObject.homePageMyntra(testContextSetup.test.URL);
	}
	@When("User select T-Shirts for Men")
	public void user_select_t_shirts_for_men() {
	    testContextSetup.myntraPageObject.selectTShirtMen();
	}
	@When("^User Select Brand of T-Shirts as (.+)$")
	public void user_select_brand_of_t_shirts(String brand) {
	    testContextSetup.myntraPageObject.selectBrand(brand);
	}
	@Then("User is able to see list of T-shirts with selected name")
	public void user_is_able_to_see_list_of_t_shirts_with_selected_van_huesen_name() {
	    testContextSetup.myntraPageObject.listOfTshirts();
	}
	@Then("Verify if user is able to see list of T-shirts in descending order of discounted price with all the details of product")
	public void verify_if_user_is_able_to_see_list_of_t_shirts_in_descending_order_of_discounted_price_with_all_the_details_of_product() {
	    testContextSetup.myntraPageObject.descendingOrder();
	}

}
