package stepDefination;

import java.io.IOException;

import io.cucumber.java.en.*;
import utils.TestContextSetup;

public class CapabilitiesStepDef {
	TestContextSetup testContextSetup;
	
	public CapabilitiesStepDef(TestContextSetup testContextSetup) {
		this.testContextSetup=testContextSetup;
	}
	
	@Given("User is on automate capabilies doc page")
	public void user_is_on_automate_capabilies_doc_page(){
	    testContextSetup.capabilitiesPageObject.capabilitiesPage(testContextSetup.test.URL);
	}
	@When("^User select (.+) as the operating system$")
	public void user_select_windows_as_the_operating_system(String os) throws InterruptedException {
	    // Write code here that turns the phrase above into concrete actions
		testContextSetup.capabilitiesPageObject.userSelectOS(os);
	}
	@When("User select Windows {int} as the device")
	public void user_select_windows_as_the_device(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@When("User select chrome126 as the browser")
	public void user_select_chrome126_as_the_browser() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("code section on the right-hand side should reflect the selected Windows, Windows {int} and chrome126")
	public void code_section_on_the_right_hand_side_should_reflect_the_selected_windows_windows_and_chrome126(Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

}
