package stepDefination;

import io.cucumber.java.en.*;
import utils.TestContextSetup;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;

public class SearchProductStepDef {
	
	public WebDriver driver;
	public String offersPageProductName;
	TestContextSetup testContextSetup;
	
	public SearchProductStepDef(TestContextSetup testContextSetup){
		this.testContextSetup=testContextSetup;
	}
	
	@Given("User is on GreenCart Landing page")
	public void user_is_on_green_cart_landing_page() throws InterruptedException {
		testContextSetup.searchProductPageObject.userOnLandingPage(testContextSetup.test.URL);
	}
	
	@When("Search with short name {string} and extracted actual name of product")
	public void search_with_short_name_and_extracted_actual_name_of_product(String shortname) throws InterruptedException {
	    testContextSetup.searchProductPageObject.getProductNamefromLandingPage(shortname);
	    
	}
	
	@Then("User searched for same shortname in offers page to check if product exist with same name")
	public void user_searched_for_same_shortname_in_offers_page_to_check_if_product_exist() {
	    driver.findElement(By.linkText("Top Deals")).click();
	    testContextSetup.genericUtils.switchWindowToChild(); 
	    driver.findElement(By.xpath("//input[@type='search']")).sendKeys("tom");
	    offersPageProductName = driver.findElement(By.cssSelector("td:nth-child(1)")).getText();
	    
	}
	
//	@And("Validate product name in offers page matches with Landing Page")
//	public void validate_product_name() {
//		Assert.assertEquals(landingPageProductName, offersPageProductName);
//	}


}
