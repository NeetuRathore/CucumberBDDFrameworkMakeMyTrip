package stepDefination;

import org.openqa.selenium.By;

import io.cucumber.java.en.*;
import utils.TestContextSetup;

public class CheckOutStepDef {
	TestContextSetup testContextSetup;
	
	public CheckOutStepDef(TestContextSetup testContextSetup) {
		this.testContextSetup = testContextSetup;
	}
	
	@When("^User select (.+) from landing page and sets (.+) of product$")
	public void user_select_vegetable_from_landing_page_and_sets_quantity_of_product(String Vegetable, String Quantity) throws InterruptedException {
		testContextSetup.checkoutPageObject.selectProductWithQuantity(Vegetable, Quantity );
	}
	
	@When("User add product to the Cart")
	public void user_add_product_to_cart() {
	    testContextSetup.checkoutPageObject.addProducttoCart();
	}
	
	@When("User is able to proceed with checkout of product")
	public void user_is_able_to_proceed_with_checkout_of_product() {
	    
	}
	
	@Then("User is able to see checkout page")
	public void user_is_able_to_see_checkout_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}


}
