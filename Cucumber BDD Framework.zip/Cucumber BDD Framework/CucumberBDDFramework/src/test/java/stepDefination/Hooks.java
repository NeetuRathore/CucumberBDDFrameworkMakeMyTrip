package stepDefination;

import java.io.IOException;

import org.openqa.selenium.WebDriver;

import io.cucumber.java.*;
import utils.TestContextSetup;

public class Hooks {
	TestContextSetup testContextSetup;
	
	public Hooks(TestContextSetup testContextSetup){
		this.testContextSetup=testContextSetup;
	}
	
	@After
	public void afterScenarios() throws IOException {
		testContextSetup.test.setUpBrowser().quit();
	}

}
