package pageObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class CheckoutPageObject {
	
	private WebDriver driver;
	private By search = By.xpath("//input[@type='search']");
	private By quantity = By.xpath("//input[@class='quantity']");
	private By addToCart = By.xpath("//button[text()='ADD TO CART']");
	
	public CheckoutPageObject(WebDriver driver) {
		this.driver=driver;
	}
	
	public void selectProductWithQuantity(String Vegetable, String Quantity) throws InterruptedException {
		driver.findElement(search).sendKeys(Vegetable);
		Thread.sleep(1000);
		driver.findElement(quantity).sendKeys(Quantity);
		Thread.sleep(1000);
	}
	
	public void addProducttoCart() {
		driver.findElement(addToCart).click();
	}
	
	
	

}
