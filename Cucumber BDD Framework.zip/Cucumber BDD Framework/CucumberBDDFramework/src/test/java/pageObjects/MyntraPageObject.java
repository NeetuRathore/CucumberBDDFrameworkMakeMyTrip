package pageObjects;

import java.io.Console;
import java.time.Duration;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class MyntraPageObject {
	
	WebDriver driver;
	
	By men = By.xpath("//div[@class='desktop-navLink']/a[text()='Men']");
	By tshirt = By.xpath("//*[@id=\"desktop-header-cnt\"]/div[2]/nav/div/div[1]/div/div/div/div/li[1]/ul/li[2]/a");
	By search_for_brand = By.xpath("//input[@placeholder='Search for Brand']");
	By select_brand = By.xpath("//ul[@class='brand-list']//li[1]");
	By list = By.xpath(".results-base>.product-base");
	By discountPrize = By.xpath("//span[@class='product-discountedPrice']");
	By discountPercentage = By.xpath("//span[@class='product-discountPercentage']");
	By imgLink = By.xpath("//li[@class='product-base']/a");
	
	
	public MyntraPageObject(WebDriver driver) {
		this.driver=driver;
	}
	
	public void homePageMyntra(String url) {
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	}
	
	public void selectTShirtMen() {
		Actions action = new Actions(driver);
        // mouse hover on men to get tshirt option
		action.moveToElement(driver.findElement(men)).perform();
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		js.executeScript("arguments[0].click();",driver.findElement(tshirt));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(2));
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//h1[text()='Men T-shirts']")));
	}
	
	public void selectBrand(String Brand) {
		
		JavascriptExecutor js = (JavascriptExecutor)driver;
		driver.findElement(By.cssSelector("div.vertical-filters-filters.brand-container > div.filter-search-filterSearchBox")).click();
		//js.executeScript("arguments[0].click();",driver.findElement(By.cssSelector("div.vertical-filters-filters.brand-container > div.filter-search-filterSearchBox")));
		//js.executeScript("arguments[0].setAttribute('value', '" + Brand +')",driver.findElement(search_for_brand));
		driver.findElement(search_for_brand).sendKeys(Brand);
		driver.findElement(select_brand).click();
		
	}
	
	public void listOfTshirts() {
		List<WebElement> productList = driver.findElements(list);
		for(int i=0;i<productList.size();i++) {
			Assert.assertEquals(productList.get(0).isDisplayed(), true);	
		}	
	}
	
	public void descendingOrder() {
		
		List<WebElement> discountPrizeList = driver.findElements(discountPrize);
		List<WebElement> discountPercentageList = driver.findElements(discountPercentage);
		List<WebElement> imgLinkList = driver.findElements(imgLink);
		for(int i=0;i<imgLinkList.size();i++) {
			System.out.println(imgLinkList.get(i).getAttribute("href"));
		}
		
		for(int i=0;i<discountPrizeList.size();i++) {
			String value = discountPrizeList.get(i).getText().split(".")[2]; 
		}
		
	    
		
	}
	

}
