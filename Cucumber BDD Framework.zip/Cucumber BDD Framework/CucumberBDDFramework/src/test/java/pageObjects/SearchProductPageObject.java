package pageObjects;
import java.util.Properties;

import org.openqa.selenium.*;

public class SearchProductPageObject {
	private WebDriver driver;
	public String landingPageProductName;
	
	public SearchProductPageObject(WebDriver driver) {
		this.driver=driver;	
	}
	
	public void userOnLandingPage(String URL) throws InterruptedException {
		driver.get(URL);
		driver.manage().window().maximize();
		Thread.sleep(1000);	
	}
	
	public void getProductNamefromLandingPage(String shortname) throws InterruptedException {
		driver.findElement(By.xpath("//input[@class='search-keyword']")).sendKeys(shortname);
	    Thread.sleep(2000);
	    landingPageProductName = driver.findElement(By.xpath("//h4[@class='product-name']")).getText().split("-")[0].trim();
	    System.out.println(landingPageProductName + "extracted from Home Page");
	}

}
