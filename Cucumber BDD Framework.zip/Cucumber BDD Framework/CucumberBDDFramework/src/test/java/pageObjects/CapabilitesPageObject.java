package pageObjects;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CapabilitesPageObject {
	
	WebDriver driver;
	
	String os = "//span[@aria-label='%']";
	By capabilityIFrame = By.xpath("//iframe[@data-id='capability-iframe']");
	By browser_or_device_combination_button = By.cssSelector("section > span > button");
	
	public CapabilitesPageObject(WebDriver driver) {
		this.driver=driver;	
	}
	
	public void capabilitiesPage(String Url) {
		driver.get(Url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	}
	
	public void userSelectOS(String OS) throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		WebDriverWait wait = new WebDriverWait(driver,Duration.ofSeconds(2));
		WebElement ele=wait.until(ExpectedConditions.elementToBeClickable(capabilityIFrame));
		driver.switchTo().frame(ele);
		
//		Thread.sleep(2000);
//		
		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(browser_or_device_combination_button));
		js.executeScript("arguments[0].click();", driver.findElement(browser_or_device_combination_button));
//		
//		js.executeScript("arguments[0].scrollIntoView();", driver.findElement(By.xpath(os.replaceAll("%", OS))));
//		driver.findElement(By.xpath(os.replaceAll("%", OS))).click();
	}

}
